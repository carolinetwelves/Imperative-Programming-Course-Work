// array_pointers.h Lab 5 SYSC2006

#ifndef ARRAY_POINTERS_H
#define ARRAY_POINTERS_H

// Exercise 1
int find_max_v0(const int ar[], int n);
int find_max_v1(const int *arp, int n);
int find_max_v2(const int *arp, int n);

// Exercise 2
int count_in_array(int a[], int n, int target);


// Exercise 3
_Bool array_compare(int arr1[], int arr2[], int n);

#endif